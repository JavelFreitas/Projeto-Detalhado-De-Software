package main.app.player;

public interface IPlayer {
    
    
}