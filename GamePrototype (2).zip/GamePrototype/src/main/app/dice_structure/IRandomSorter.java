package main.app.dice_structure;

public interface IRandomSorter {
    int getRandomInteger();
}