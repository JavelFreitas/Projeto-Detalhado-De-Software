package main.app.game_root;
import main.app.game_map.Map;

public class App {
    public static void main(String[] args) throws Exception {
        Map mapinha = new Map();
        mapinha.showMap();
    }
}